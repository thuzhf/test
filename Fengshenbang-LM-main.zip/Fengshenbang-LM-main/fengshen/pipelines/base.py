_CONFIG_MODEL_TYPE = 'fengshen_model_type'
_CONFIG_TOKENIZER_TYPE = 'fengshen_tokenizer_type'
